export class Feedback {
    dailyweather!:String;
    friendliness!:String;
    usefulness!:String;
    comment!:String;
    overallexperience!:String
    
}
