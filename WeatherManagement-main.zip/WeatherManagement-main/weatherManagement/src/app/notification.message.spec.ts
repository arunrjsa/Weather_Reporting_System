import { NotificationMessage } from './notification.message';

describe('NotificationMessage', () => {
  it('should create an instance', () => {
    expect(new NotificationMessage()).toBeTruthy();
  });
});
