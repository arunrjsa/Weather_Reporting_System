export class NotificationMessage {
    message: string | undefined;
    type: NotificationType | undefined
}
export enum NotificationType {
    info = 0,
}

