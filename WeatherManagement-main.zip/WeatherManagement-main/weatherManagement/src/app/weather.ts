export class Weather {
    city?: String;
    temperature?: String;
    humidity?: String;
    pressure?: String;
    sunrise?: String;
    sunset?: String;
    geocoords?: String;
}

