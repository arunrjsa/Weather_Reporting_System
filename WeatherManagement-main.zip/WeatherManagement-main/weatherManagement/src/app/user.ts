export class User {
    name!:String;
    location!:String;
    email!:String;
    contact!:String;
    password!:String;
    cpassword!:String;
}
